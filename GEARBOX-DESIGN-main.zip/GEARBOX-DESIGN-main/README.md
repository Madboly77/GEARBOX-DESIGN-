# GEARBOX-DESIGN
Gearbox Design Uni project
